# zbxss
cli tool to probe xss payload in http headers for blind xss
